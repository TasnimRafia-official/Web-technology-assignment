///array for players' position
var player = [0,0];


var board = 0;
//repeats until player reaches the limit (25)
while(board < 25)
{
  //repetition for update players' position
  for(var i=0; i<2; i++)
  {
      //rolling random die for each player
    var die = (Math.floor(Math.random() * 6) + 1);

    ///print player position and the value of die
    document.write("&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp");
    document.write("Player " + (i+1) + "  rolls... Die: " + die + ", ");

    ///update player position
    player[i] = player[i] + die;

    //decision statements
      //snake at position 15 --> fall to position 5
      if(player[i]==15)
        {
          player[i] = 5;
            document.write("SNAKE !!!, go back to position 5" + "<br>");
        }

      //snake at position 23 --> fall to position 13
      else if(player[i]==23)
        {
          player[i] = 13;
            document.write("SNAKE !!!, go back to position 13" + "<br>");
        }

      //ladder at position 2 --> advance to position 12
      else if(player[i]==2)
        {
          player[i] = 12;
            document.write("Bravo !!! You got a LADDER !!! Advance to position 12" + "<br>");
        }

      //ladder at position 10 --> advance to position 20
      else if(player[i]==10)
        {
          player[i] = 20;
            document.write("Bravo !!! You got a LADDER !!! Advance to position 20" + "<br>");
        }

      //display output
      else {
        document.write("Move to position " + player[i] + "<br>");
      }

    ///statement for beaking loop when any player wins
    if(player[i] > 24)
        {
            document.write("&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp");
            document.write("Player " + (i+1) + " passes the finishing square. Player " + (i+1) + " wins the game !!!" + "<br>");
            document.write("CONGRATS !!!")
            break;
        }
  }

  ///print a blank line to make it decent
  document.write("<br>");

  ///update value of board by maximum position between players
  if (player[0] > player[1])
  {
    board = player[0];
  }
  else {
    board = player[1]
  }

}

  document.write("Game ends..." + "<br>");
